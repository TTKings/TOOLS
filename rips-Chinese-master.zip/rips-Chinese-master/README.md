##                                                             Rips0.55汉化版

### 0x01简介

RIPS是一款PHP开发的开源的PHP[代码审计工具](http://bbs.ichunqiu.com/portal.php)，由国外的安全研究者Johannes Dahse开发，目前开源的最新版本是0.55。程序小巧玲珑，仅有不到500kb，其中的PHP语法分析非常精准，可以实现跨文件变量和函数追踪，误报率较低。并有拥有简单易懂的用户界面，因此被许多安全研究人员钟爱，因此RIPS可谓是PHP代码审计之利器。    

RIPS项目的官网为http://rips-scanner.sourceforge.net/和 https://www.ripstech.com/  

目前RIPS的免费开源版本已停止了程序更新，但官方目前给出了下个版本的说明 

![ak1Ymq.png](https://s1.ax1x.com/2020/07/28/ak1Ymq.png)


### 0x02汉化预览

汉化前的官方原版如图

![ak1t00.png](https://s1.ax1x.com/2020/07/28/ak1t00.png)

个人汉化后的如图所示

![ak1N7V.png](https://s1.ax1x.com/2020/07/28/ak1N7V.png)
因为是自己三年前汉化的，个人水平有限，如有错误，欢迎大家斧正

期待大家的issue~    


### 3.使用说明

下载RIPS后将其解压放入PHPstduy的目录下即可使用（无需进行任何数据库配置）

**记住路径一定不要存在中文！！！**



### 4.Paper

其他更多的使用注意事项，在此不过多赘述

各位看官有兴趣的话，欢迎浏览https://bbs.ichunqiu.com/forum.php?mod=viewthread&tid=42115&highlight=rips
